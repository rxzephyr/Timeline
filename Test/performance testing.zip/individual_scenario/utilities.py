def create_user_data(number: int):
    data = dict()
    for i in range(number):
        data['test' + str(i)] = 'test' + str(i)
    return data

# if __name__ == '__main__':
#     print(create_user_data(10))
