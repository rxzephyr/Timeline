import json

from locust import HttpLocust, TaskSet, task


def create_user_data(number: int):
    data = dict()
    for i in range(number):
        data['test' + str(i)] = 'test'
    return data


class SignUpTasks(TaskSet):
    def on_start(self):
        # if self.locust.user_data:
        #     username, password = self.locust.user_data.popitem()
        #     self.locust.username = username
        #     self.locust.display_name = username
        #     self.locust.password = password
        # else:
        #     print("quit......")
        #     self.interrupt()
        pass

    @task
    def sign_up(self):
        if self.locust.user_data:
            username, password = self.locust.user_data.popitem()
            self.locust.username = username
            self.locust.display_name = username
            self.locust.password = password
        else:
            print("quit......")
            self.interrupt()

        header = {'content-type': 'application/json'}
        body = dict()
        body['displayName'] = self.locust.username
        body['username'] = self.locust.username
        body['password'] = self.locust.password
        with self.client.post("/register", json.dumps(body), headers = header, catch_response = True) as response:
            print(response.content)
            if "result" in json.loads(response.text):
                if json.loads(response.text)['result'] == 'success':
                    response.success()
                else:
                    response.failure("Sign Up failed.")
            else:
                response.failure("Unknown issue.")


class SignUpUser(HttpLocust):
    task_set = SignUpTasks
    user_data = create_user_data(100000)
    # user_data = create_user_data(1000)
    host = "http://127.0.0.1:8080"
    min_wait = 0
    max_wait = 0
