import json
import random
from locust import HttpLocust, TaskSet, task


class SignInTask(TaskSet):
    def on_start(self):
        pass

    @task
    def sign_in(self):
        if self.locust.data:
            username = self.locust.data[random.randint(0, self.locust.num_username - 1)]
            header = {'content-type': 'application/json'}
            body = dict()
            body['username'] = username
            body['password'] = self.locust.password
            with self.client.post("/login", json.dumps(body), headers = header, catch_response = True) as response:
                print(response.content)
                if json.loads(response.text)['status'] == '200':
                    response.success()
                else:
                    response.failure("Login failed.")
        else:
            print("Quit.")
            self.interrupt()


class SignInUser(HttpLocust):
    username = "test"
    password = "test"
    num_username = 1000
    data = list()
    for i in range(num_username):
        data.append(username + str(random.randint(0, num_username - 1)))
    task_set = SignInTask
    host = "http://127.0.0.1:8080"
    min_wait = 0
    max_wait = 0