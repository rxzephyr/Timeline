import json
import random
from locust import HttpLocust, TaskSet, task
from datetime import datetime


def iso_format(dt: datetime):
    try:
        utc = dt + dt.utcoffset()
    except TypeError:
        utc = dt
    iso_string = datetime.strftime(utc, '%Y-%m-%dT%H:%M:%S.{0}Z')
    return iso_string.format(int(round(utc.microsecond / 1000.0)))


class BrowseTaskSet(TaskSet):
    def __init__(self, parent):
        super().__init__(parent)
        self.jwt_token = None
        self.user_id = None

    def on_start(self):
        if self.locust.data:
            username, password = self.locust.data.popitem()
            header = {'content-type': 'application/json'}
            body = dict()
            body['username'] = username
            body['password'] = password
            with self.client.post("/login", json.dumps(body), headers = header, catch_response = True) as response:
                print(response.content)
                res = json.loads(response.text)
                if res['status'] == '200' and res['jwtToken'] and res['result']:
                    self.jwt_token = res['jwtToken']
                    self.user_id = res['result']
                else:
                    response.failure("Login failed.")
                    self.interrupt()
        else:
            print("Quit.")
            self.interrupt()

    @task
    def browse(self):
        body = dict()
        body['contentStartId'] = -1
        body['end'] = ''
        body['start'] = ''
        body['numberToRetrieve'] = 5
        body['userId'] = self.user_id
        header = {'authorization': 'Bearer ' + self.jwt_token, 'content-type': 'application/json'}
        print(json.dumps(body))
        with self.client.post("/api/content/detail/by_id_range", json.dumps(body), headers = header,
                              catch_response = True) as response:
            print(response.content)
            if 'result' in json.loads(response.text):
                if json.loads(response.text)['result'] == 'success':
                    response.success()
                else:
                    response.failure('Browse failed.')
            else:
                response.failure('Unknown issue.')


class BrowseUser(HttpLocust):
    task_set = BrowseTaskSet
    num_username = 1000
    username = "test"
    password = "test"
    number = random.sample(range(num_username), num_username)
    data = dict()
    for i in number:
        data[username + str(i)] = password
    host = "http://127.0.0.1:8080"
    min_wait = 0
    max_wait = 0