import json
import random
from locust import HttpLocust, TaskSet, task
from datetime import datetime


def iso_format(dt: datetime):
    try:
        utc = dt + dt.utcoffset()
    except TypeError:
        utc = dt
    iso_string = datetime.strftime(utc, '%Y-%m-%dT%H:%M:%S.{0}Z')
    return iso_string.format(int(round(utc.microsecond / 1000.0)))


class MixedTaskSet(TaskSet):
    def __init__(self, parent):
        super().__init__(parent)
        self.jwt_token = None
        self.user_id = None

    def on_start(self):
        if self.locust.data:
            username, password = self.locust.data.popitem()
            body = dict()
            body['username'] = username
            body['password'] = password
            self.locust.body = body
            self.sign_in()
        else:
            print("Quit.")
            self.interrupt()

    def sign_in(self):
        header = {'content-type': 'application/json'}
        with self.client.post("/login", json.dumps(self.locust.body), headers = header,
                              catch_response = True) as response:
            print(response.content)
            res = json.loads(response.text)
            if res['status'] == '200' and 'jwtToken' in res and 'result' in res:
                self.jwt_token = res['jwtToken']
                self.user_id = res['result']
            else:
                response.failure("Login failed.")
                self.interrupt()

    @task(1)
    def publish(self):
        body = dict()
        body['content'] = dict()
        content = {'data': 'test', 'imgUrl': ''}
        body['content'] = json.dumps(content)
        body['publishTime'] = iso_format(datetime.now())
        body['userId'] = self.user_id
        header = {'authorization': 'Bearer ' + self.jwt_token, 'content-type': 'application/json'}
        print(json.dumps(body))
        with self.client.post("/api/content/create", json.dumps(body), headers = header,
                              catch_response = True) as response:
            print(response.content)
            if 'result' in json.loads(response.text):
                if json.loads(response.text)['result'] == 'success':
                    response.success()
                elif json.loads(response.text)['status'] == '403':
                    self.sign_in()
                    self.publish()
                else:
                    response.failure('Publish failed.')
            else:
                response.failure('Unknown issue.')

    @task(9)
    def browse(self):
        body = dict()
        body['contentStartId'] = -1
        body['end'] = ''
        body['start'] = ''
        body['numberToRetrieve'] = 5
        body['userId'] = self.user_id
        header = {'authorization': 'Bearer ' + self.jwt_token, 'content-type': 'application/json'}
        print(json.dumps(body))
        with self.client.post("/api/content/detail/by_id_range", json.dumps(body), headers = header,
                              catch_response = True) as response:
            print(response.content)
            if 'result' in json.loads(response.text):
                if json.loads(response.text)['result'] == 'success':
                    response.success()
                elif json.loads(response.text)['status'] == '403':
                    self.sign_in()
                    self.publish()
                else:
                    response.failure('Browse failed.')
            else:
                response.failure('Unknown issue.')


class MixedUser(HttpLocust):
    task_set = MixedTaskSet
    num_username = 3000
    username = "test"
    password = "test"
    number = random.sample(range(num_username), num_username)
    data = dict()
    for i in number:
        data[username + str(i)] = password
    host = "http://127.0.0.1:8080"
    min_wait = 0
    max_wait = 0
