package edu.jl.electron;

import edu.jl.Constants;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class SignUpElectronTest {

	private WebDriver driver = null;

	@Before
	public void setup() throws IOException {
		String binaryPath = "/node_modules/electron/dist/electron.exe";
		String appPath = "/release/timeline_desktop-win32-x64";

		File directory = new File(".");
		String currentPath = directory.getCanonicalPath();

		System.setProperty("webdriver.chrome.driver", Constants.CHROME_DRIVER_PATH);
		ChromeOptions chromeOptions = new ChromeOptions();
		chromeOptions.setBinary(currentPath + binaryPath);
		chromeOptions.addArguments(currentPath + appPath);
		driver = new ChromeDriver(chromeOptions);
	}

	@Test
	public void test() {

	}

	@After
	public void teardown() {
		driver.quit();
	}
}
