package edu.jl;

public interface Constants {
	String CHROME_DRIVER_PATH = "src/test/java/resources/drivers/chromedriver.exe";
	String SINGLE_TEST_USERNAME = "test";
	String SINGLE_TEST_PASSWORD = "test";
	String SINGLE_TEST_NICKNAME = "test";
	Integer TIMEOUT_IN_SECONDS = 20;
}
