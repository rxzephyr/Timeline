package edu.jl.web;

import org.junit.*;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameter;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Collection;
import java.util.concurrent.TimeUnit;

import static edu.jl.Constants.*;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.equalTo;

@RunWith(Enclosed.class)
public class PublishTest {
	private static WebDriver driver;
	private static String url;

	public static class ExceptionalScenario {
		@Before
		public void setUp() throws Exception {
			url = "http://localhost:3000";

			System.setProperty("webdriver.chrome.driver", CHROME_DRIVER_PATH);
			ChromeOptions chromeOptions = new ChromeOptions();
			chromeOptions.addArguments("headless");
			driver = new ChromeDriver(chromeOptions);
			driver.get(url);
		}

		@Test
		public void PublishCannotBeAccessedWhenNotSignedIn() throws Exception {
			WebDriverWait wait = new WebDriverWait(driver, TIMEOUT_IN_SECONDS);

		//		jump to publish page

			WebElement publishButton = driver.findElement(By.xpath("//a[@href='/publish']"));
			wait.until(ExpectedConditions.elementToBeClickable(publishButton));
			publishButton.click();

		//		judge if the Error message is displayed.
			wait.until(ExpectedConditions.and(
					ExpectedConditions.visibilityOfElementLocated(By.xpath("//p[text()='Please login first.']")),
					ExpectedConditions.urlToBe(url + "/")));

		}

		@After
		public void tearDown() throws Exception {
			driver.close();
			driver.quit();
		}
	}

	@RunWith(Parameterized.class)
	public static class NormalScenario {
		@Parameter(value = 0)
		public boolean isBasic;
		@Parameter(value = 1)
		public Integer pictureNumber;
		@Parameter(value = 2)
		public String fileType;
		@Parameter(value = 3)
		public String picturePath1;
		@Parameter(value = 4)
		public String picturePath2;
		@Parameter(value = 5)
		public boolean pictureError;
		@Parameter(value = 6)
		public String textPath;
		@Parameter(value = 7)
		public boolean textError;

		@Parameterized.Parameters(name = "{index}, isBasic={0}, pictureNumber={1}, fileType={2}, picturePath1={3},picturePath2={4}, pictureError={5}, textPath={6}, textError={7}")
		public static Collection<Object[]> testData() {
			return Arrays.asList(new Object[][]{
					{true, 1, "jpg", "/src/test/java/resources/images/good jpg.jpg", "", false, "/src/test/java/resources/texts/500.txt", false},
					{false, 2, "jpg", "/src/test/java/resources/images/good jpg.jpg", "/src/test/java/resources/images/good jpg - copy.jpg", true, "/src/test/java/resources/texts/500.txt", false},
					{false, 0, "", "", "", false, "/src/test/java/resources/texts/500.txt", false},
					{false, 1, "jpg", "/src/test/java/resources/images/bad jpg.jpg", "", true, "/src/test/java/resources/texts/500.txt", false},
					{false, 1, "png", "/src/test/java/resources/images/good png.png", "", false, "/src/test/java/resources/texts/500.txt", false},
					{false, 1, "123", "/src/test/java/resources/images/bad 123.123", "", true, "/src/test/java/resources/texts/500.txt", false},
					{false, 1, "jpg", "/src/test/java/resources/images/good jpg.jpg", "", false, "/src/test/java/resources/texts/0.txt", true},
					{false, 1, "jpg", "/src/test/java/resources/images/good jpg.jpg", "", false, "/src/test/java/resources/texts/1001.txt", true}
			});
		}

		@Before
		public void setUp() throws Exception {
			url = "http://localhost:3000";

			System.setProperty("webdriver.chrome.driver", CHROME_DRIVER_PATH);
			ChromeOptions Chromeoptions = new ChromeOptions();
			Chromeoptions.addArguments("headless");
			driver = new ChromeDriver(Chromeoptions);
			driver.get(url);
		}

		void SignIn() throws Exception {
			WebDriverWait wait = new WebDriverWait(driver, TIMEOUT_IN_SECONDS);

			// click Login button
			WebElement signInButton = driver.findElement(By.xpath("//a[@href='/login']"));
			wait.until(ExpectedConditions.elementToBeClickable(signInButton));
			signInButton.click();


			// judge if the current page is login
			wait.until(ExpectedConditions.and(
					ExpectedConditions.urlToBe(url + "/login"),
					ExpectedConditions.textToBePresentInElementLocated(By.xpath("//h2"), "Sign In")));


			// fill in login form
			WebElement usernameInput = driver.findElement(By.xpath("//input[@placeholder='Username']"));
			usernameInput.sendKeys(SINGLE_TEST_USERNAME);

			WebElement passwordInput = driver.findElement(By.xpath("//input[@placeholder='Password']"));
			passwordInput.sendKeys(SINGLE_TEST_PASSWORD);

			Actions action = new Actions(driver);
			action.sendKeys(Keys.ENTER).perform();

			// judge if login successfully
			wait.until(ExpectedConditions.urlToBe(url + "/"));

		}

		@Test
		public void Publish() throws Exception {
			WebDriverWait wait = new WebDriverWait(driver, TIMEOUT_IN_SECONDS);
			File directory = new File(".");
			String currentPath = directory.getCanonicalPath();

			// Sign in
			SignIn();

			// jump to publish page
			WebElement publishButton = driver.findElement(By.xpath("//a[@href='/publish']"));
			wait.until(ExpectedConditions.elementToBeClickable(publishButton));
			publishButton.click();

			// judge if page goes to publish
			wait.until(ExpectedConditions.urlToBe(url + "/publish"));

			// input picture
			if (pictureNumber != 0) {
				WebElement pictureFile = driver.findElement(By.xpath("//input[@type='file']"));
				if (pictureNumber == 1) {
					pictureFile.sendKeys(currentPath + picturePath1);
				} else {
					try {
						pictureFile.sendKeys(currentPath + picturePath1 + "\n" + currentPath + picturePath2);
					} catch (WebDriverException e) {
						Assert.assertThat(e.getMessage(), containsString("multiple"));
						// no pictureError afterwards, return
						pictureError = false;
					}
				}
			}

            // judge if picture upload performs correctly
			String pictureUrl = null;
			if (!pictureError) {
				if (pictureNumber == 1) {
					wait.until(ExpectedConditions.and(
							ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='ui segment']/p[contains(text(), 'good')]")),
							ExpectedConditions.visibilityOfElementLocated(By.xpath("//img[contains(@src, 'good')]"))));
					pictureUrl = driver.findElement(By.xpath("//img[contains(@src, 'good')]")).getAttribute("src");
				}
			} else {
				wait.until(ExpectedConditions.alertIsPresent());
				Alert alert = driver.switchTo().alert();
				alert.accept();
			}

			// input text
			WebElement textArea = driver.findElement(By.xpath("//textarea"));

			String textInput = new String(Files.readAllBytes(Paths.get(currentPath + textPath)));
			textArea.sendKeys(textInput);

			WebElement submitButton = driver.findElement(By.xpath("//button[text()='Submit']"));
			submitButton.click();

            // judge if text is sent correctly
			if (!textError) {
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='ui positive message']")));

				// jump to timeline page
				WebElement timeLineButton = driver.findElement(By.xpath("//a[@href='/main']"));
				timeLineButton.click();

				// judge if text is on timeline page
				wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//section/div[2]/div[2]/div[3]/div[text() =" + "'" + textInput + "'" + "]")));
				if (pictureNumber == 1 && !pictureError) {
				// judge if jpg is on timeline page
					wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//img[contains(@src, " + "\'" + pictureUrl + "\'" + ")]")));
				}
			} else {
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='ui negative message']")));
			}

            // Logout successfully
			WebElement logoutButton = driver.findElement(By.xpath("//div[@class='right menu']"))
					.findElement(By.className("item"));
			wait.until(ExpectedConditions.elementToBeClickable(logoutButton));
			logoutButton.click();
		}

		@After
		public void tearDown() throws Exception {
			driver.close();
			driver.quit();
		}
	}
}
