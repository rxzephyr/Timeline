package edu.jl.web;

import org.junit.After;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import static edu.jl.Constants.*;
import static edu.jl.Constants.SINGLE_TEST_PASSWORD;


@FixMethodOrder(MethodSorters.NAME_ASCENDING)

public class BrowseTest {

	private WebDriver driver;
	private String url;


	@Before
	public void setUp() throws Exception {
		url = "http://localhost:3000";

		System.setProperty("webdriver.chrome.driver", CHROME_DRIVER_PATH);
		ChromeOptions chromeOptions = new ChromeOptions();
		chromeOptions.addArguments("headless");
		driver = new ChromeDriver(chromeOptions);
		driver.get(url);
	}

	@Test
	public void _0_TimelineCannotBeAccessedWhenNotSignedIn() throws Exception {
		WebDriverWait wait = new WebDriverWait(driver, TIMEOUT_IN_SECONDS);

		// jump to publish page
		WebElement publishButton = driver.findElement(By.xpath("//a[@href='/main']"));
		wait.until(ExpectedConditions.elementToBeClickable(publishButton));
		publishButton.click();

		// judge if the Error message is displayed.
		wait.until(ExpectedConditions.and(
				ExpectedConditions.visibilityOfElementLocated(By.xpath("//p[text()='Please login first.']")),
				ExpectedConditions.urlToBe(url + "/")));

	}

	private void SignIn() {
		WebDriverWait wait = new WebDriverWait(driver, TIMEOUT_IN_SECONDS);

		// click Login button
		WebElement signInButton = driver.findElement(By.xpath("//a[@href='/login']"));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@href='/login']")));
		signInButton.click();


		// judge if the current page is login
		wait.until(ExpectedConditions.and(
				ExpectedConditions.urlToBe(url + "/login"),
				ExpectedConditions.textToBePresentInElementLocated(By.xpath("//h2"), "Sign In")));


		// fill in login form
		WebElement usernameInput = driver.findElement(By.xpath("//input[@placeholder='Username']"));
		usernameInput.sendKeys(SINGLE_TEST_USERNAME);

		WebElement passwordInput = driver.findElement(By.xpath("//input[@placeholder='Password']"));
		passwordInput.sendKeys(SINGLE_TEST_PASSWORD);

		Actions action = new Actions(driver);
		action.sendKeys(Keys.ENTER).perform();

		// judge if login successfully
		wait.until(ExpectedConditions.urlToBe(url + "/"));
	}

	@Test
	public void _1_Browse() {
		SignIn();

		WebDriverWait wait = new WebDriverWait(driver, TIMEOUT_IN_SECONDS);

		// jump to publish page
		WebElement publishButton = driver.findElement(By.xpath("//a[@href='/main']"));
		wait.until(ExpectedConditions.elementToBeClickable(publishButton));
		publishButton.click();

		// judge if TimeLine is opened successfully

		wait.until(ExpectedConditions.and(
				ExpectedConditions.urlToBe(url + "/main"),
				ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='ui container main ui']")),
				ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='content'][text()='Time Line']"))
		));


		// Logout successfully
		WebElement logoutButton = driver.findElement(By.xpath("//div[@class='right menu']"))
				.findElement(By.className("item"));
		wait.until(ExpectedConditions.elementToBeClickable(logoutButton));
		logoutButton.click();
	}


	@After
	public void tearDown() throws Exception {
		driver.close();
		driver.quit();
	}
}
