package edu.jl.web;

import edu.jl.Constants;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameter;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.Arrays;
import java.util.Collection;

@RunWith(Parameterized.class)
public class SignInTest {

	@Parameter(value = 0)
	public String username;
	@Parameter(value = 1)
	public String password;
	@Parameter(value = 2)
	public boolean isBasic;
	private WebDriver driver;

	@Parameterized.Parameters(name = "{index}, isBasic={2}, username={0}, password={1}")
	public static Collection<Object[]> testData() {
		return Arrays.asList(new Object[][]{
				{"username1", "pass", true},
				{"", "pass", false},
				{"nouser", "pass", false},
				{"username1", "", false},
				{"username1", "notpass", false}
		});
	}

	@Before
	public void init() {
		System.setProperty("webdriver.chrome.driver", Constants.CHROME_DRIVER_PATH);
		ChromeOptions chromeOptions = new ChromeOptions();
		chromeOptions.addArguments("headless");
		driver = new ChromeDriver(chromeOptions);
		driver.get("http://localhost:3000");
	}

	@Test
	public void test() throws Exception {
		WebElement goToSignIn = driver.findElement(By.xpath("//a[@href='/login']"));
		WebDriverWait buttonWait = new WebDriverWait(driver, Constants.TIMEOUT_IN_SECONDS);
		buttonWait.until(ExpectedConditions.elementToBeClickable(goToSignIn));
		goToSignIn.click();
		WebElement usernameInput = driver.findElement(By.xpath("//input[@placeholder='Username']"));
		WebElement passwordInput = driver.findElement(By.xpath("//input[@placeholder='Password']"));
		usernameInput.sendKeys(username);
		passwordInput.sendKeys(password);
		WebElement signInButton = driver.findElement(By.xpath("//button"));
		buttonWait.until(ExpectedConditions.elementToBeClickable(signInButton));
		signInButton.click();
		if (isBasic) {
			WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.urlToBe("http://localhost:3000/"));
			WebElement logoutButton = driver.findElement(By.xpath("//div[@class='right menu']"))
					.findElement(By.className("item"));
			wait.until(ExpectedConditions.elementToBeClickable(logoutButton));
			logoutButton.click();
		} else {
			WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("negative")));
		}
	}

	@After
	public void dispose() {
		driver.quit();
	}
}
