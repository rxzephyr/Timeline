package edu.jl.web;

import edu.jl.Constants;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameter;
import org.junit.runners.Parameterized.Parameters;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.Arrays;
import java.util.Collection;

@RunWith(Parameterized.class)
public class SignUpTest {

    @Parameter(value = 0)
    public String username;
    @Parameter(value = 1)
    public String nickname;
    @Parameter(value = 2)
    public String password;
    @Parameter(value = 3)
    public boolean accepted;
    @Parameter(value = 4)
    public boolean isBasic;
    private WebDriver driver;

    @Parameters(name = "{index}, isBasic={4}, username={0}, nickname={1}, password={2}, accepted={3}")
    public static Collection<Object[]> testData() {
        return Arrays.asList(new Object[][]{
                {"username1", "nickname", "pass", true, true},
                {"usernameusernameusern", "nickname", "pass", true, false},
                {"", "nickname", "pass", true, false},
                {"username2", "nicknamenicknamenickn", "pass", true, false},
                {"username3", "", "pass", true, false},
                {"username4", "nickname", "passwordpasswordpasswordpasswordpasswordpasswordpasswordpasswordpassword" +
                        "passwordpasswordpasswordpasswordpasswordpasswordpasswordpasswordpasswordpasswordpassword" +
                        "passwordpasswordpasswordpasswordpasswordpasswordpasswordpasswordpasswordpasswordpassword" +
                        "password", true, false},
                {"username5", "nickname", "", true, false},
                {"username6", "nickname", "pass", false, false},
                {"username1", "nickname", "pass", true, false}
        });
    }

    @Before
    public void init() {
        System.setProperty("webdriver.chrome.driver", Constants.CHROME_DRIVER_PATH);
        ChromeOptions chromeOptions = new ChromeOptions();
        chromeOptions.addArguments("headless");
        driver = new ChromeDriver(chromeOptions);
        driver.get("http://localhost:3000");
    }

    @Test
    public void test() {
        WebElement goToSignUp = driver.findElement(By.xpath("//a[@href='/register']"));
        WebDriverWait buttonWait = new WebDriverWait(driver, Constants.TIMEOUT_IN_SECONDS);
        buttonWait.until(ExpectedConditions.elementToBeClickable(goToSignUp));
        goToSignUp.click();
        WebElement usernameInput = driver.findElement(By.xpath("//form[1]//div[2]//div//input"));
        WebElement nicknameInput = driver.findElement(By.xpath("//form[1]//div[3]//div//input"));
        WebElement passowordInput = driver.findElement(By.xpath("//form[1]//div[4]//div//input"));
        WebElement agreeCheckbox = driver.findElement(By.xpath("//form[1]//div[5]//div"));
        WebElement signUpButton = driver.findElement(By.xpath("//form[1]//button"));
        usernameInput.sendKeys(username);
        nicknameInput.sendKeys(nickname);
        passowordInput.sendKeys(password);
        if (accepted) {
            buttonWait.until(ExpectedConditions.elementToBeClickable(agreeCheckbox));
            agreeCheckbox.click();
        }
        buttonWait.until(ExpectedConditions.elementToBeClickable(signUpButton));
        signUpButton.click();
        if (isBasic) {
            WebDriverWait wait = new WebDriverWait(driver, 20);
            wait.until(ExpectedConditions.urlToBe("http://localhost:3000/login"));
        } else {
            WebDriverWait wait = new WebDriverWait(driver, 20);
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("negative")));
        }
    }

    @After
    public void dispose() {
        driver.quit();
    }
}
