const Application = require('spectron').Application;
const electronPath = "D:\\Workspace\\electron_react_test_1\\release\\timeline_desktop-win32-x64\\timeline_desktop.exe"
const chai = require('chai');
const chaiAsPromised = require('chai-as-promised');
chai.should();
chai.use(chaiAsPromised);

describe('Sign up', function () {

    const tests = [
        {username: "username1", nickname: "nickname", password: "pass", accepted: true, isBasic: true}
    ];

    const goToSignUp = "[href='/register']";
    const usernameInput = "[placeholder='Username(less than 15 characters)']";
    const nicknameInput = "[placeholder='Nickname(less than 15 characters)']";
    const passwordInput = "[placeholder='Password(less than 255 characters)']";
    const agreeCheckbox = "[class='ui checkbox']";
    const signUpSubmit = "button";

    this.timeout(10000);

    beforeEach(function () {
        this.app = new Application({
            path: electronPath,
        });
        return this.app.start()
    });

    beforeEach(function () {
        chaiAsPromised.transferPromiseness = this.app.transferPromiseness
    });

    afterEach(function () {
        if (this.app && this.app.isRunning()) {
            return this.app.stop()
        }
    });

    tests.forEach(function (test) {
        it('test', function () {
            this.app.client.waitUntilWindowLoaded()
                .click(goToSignUp)
                .setValue(usernameInput, test.username)
                .setValue(nicknameInput, test.nickname)
                .setValue(passwordInput, test.password);
            if (test.accepted === true) {
                this.app.client.waitUntilWindowLoaded().click(agreeCheckbox)
            }
            this.app.client.waitUntilWindowLoaded().click(signUpSubmit);
            if (test.isBasic === true) {
                this.app.client.waitUntilWindowLoaded().then(function () {

                });
            }
        });
    })
});