module.exports = {
    prefix: "test",
    switchPrefix: "test-switch",
    btnPrefix: "test-btn",
    inputPrefix: "test-input"
};