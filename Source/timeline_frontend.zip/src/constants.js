export const BASE_URL = 'http://192.168.50.51:8080';
export const MAX_PICTURE_SIZE = 1048576;
export const INIT_TIMELINE_SIZE=5;
