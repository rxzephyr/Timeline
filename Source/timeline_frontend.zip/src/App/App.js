import React from 'react';
import StickyMenu from '../components/menu';
import Home from "../components/home/home";

export default () => {
	return (
		<div>
			<StickyMenu/>
		</div>
	);
}