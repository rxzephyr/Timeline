import StickyMenu from './menu';

export default StickyMenu;