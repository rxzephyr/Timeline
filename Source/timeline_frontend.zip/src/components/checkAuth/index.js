import requireAuthentication from './requireAuthentication';

export default requireAuthentication;