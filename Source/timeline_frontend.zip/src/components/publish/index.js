import Publish from './publish';

export default Publish;